﻿CREATE TABLE [dbo].[AddToCart] (
[Srno] int, 
[ProductName] VARCHAR (100) NOT NULL,
[ProductImage] varchar (100) NOT NULL,
[Price] INT NULL,
[Quantity] INT NULL,
[Description] VARCHAR (100) NULL,
[Total] int,

PRIMARY KEY CLUSTERED ([ProductName] ASC)
);
select * from AddToCart;