﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodPlazaWebAPI.Models;

namespace FoodPlazaWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json")]
    public class SavoriesController : ControllerBase
    {
        private readonly MealspackContext _context;

        public SavoriesController(MealspackContext context)
        {
            _context = context;
        }

        // GET: api/Savories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Savory>>> GetSavories()
        {
            return await _context.Savories.ToListAsync();
        }

        // GET: api/Savories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Savory>> GetSavory(int id)
        {
            var savory = await _context.Savories.FindAsync(id);

            if (savory == null)
            {
                return NotFound();
            }

            return savory;
        }

        // PUT: api/Savories/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSavory(int id, Savory savory)
        {
            if (id != savory.Id)
            {
                return BadRequest();
            }

            _context.Entry(savory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SavoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Savories
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Savory>> PostSavory(Savory savory)
        {
            _context.Savories.Add(savory);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (SavoryExists(savory.Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetSavory", new { id = savory.Id }, savory);
        }

        // DELETE: api/Savories/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSavory(int id)
        {
            var savory = await _context.Savories.FindAsync(id);
            if (savory == null)
            {
                return NotFound();
            }

            _context.Savories.Remove(savory);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SavoryExists(int id)
        {
            return _context.Savories.Any(e => e.Id == id);
        }
    }
}
