﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FoodPlazaWebAPI.Models
{
    public partial class Savory
    {
        public int Id { get; set; }
        public int? Price { get; set; }
        public string Picture { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
