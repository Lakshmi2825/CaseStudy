﻿create table register(
id int,
FullName varchar(40),

MobileNumber int,
Email varchar(40),
Password varchar(20)
);
select * from register;