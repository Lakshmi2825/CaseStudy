﻿CREATE TABLE [dbo].[AddToCart] (
    [id]           INT           NOT NULL,
	[Srno]         INT           NOT NULL,
    [ProductName]  VARCHAR (100) NOT NULL,
    [ProductImage] VARCHAR (100) NOT NULL,
    [Price]        INT           NULL,
    [Quantity]     INT           NULL,
    [Description]  VARCHAR (100) NULL,
    [Total]        INT           NULL,
    PRIMARY KEY CLUSTERED ([ProductName] ASC)
);

select * from AddToCart;

