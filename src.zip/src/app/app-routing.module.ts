import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MealsPackComponent } from './meals-pack/meals-pack.component';
import { MycartComponent } from './mycart/mycart.component';
import { RegisterComponent } from './register/register.component';
import { SavoriesComponent } from './savories/savories.component';
import { SweetsComponent } from './sweets/sweets.component';

const routes: Routes = [

  {path:"home", component:HomeComponent},
  {path:"meals-pack", component:MealsPackComponent},
  {path:"sweets", component:SweetsComponent},
  {path:"login", component:LoginComponent},
  {path:"mycart", component:MycartComponent},
  {path: "savories",component:SavoriesComponent},
  {path:"register",component:RegisterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
