import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { CartService } from '../service/cart.service';
//import { CartService } from '../service/cart.service';


@Component({
  selector: 'app-sweets',
  templateUrl: './sweets.component.html',
  styleUrls: ['./sweets.component.css']
})
export class SweetsComponent implements OnInit {
  sweets:any=[];
  

 //we have fetch the functions from the service(cart service) we have created 
  constructor(private cartService:CartService,private ser:ApiService) {
    
    
   }
    ngOnInit(): void {
      
      this.ser.getAllSweetsData().subscribe((res:any)=>{

        this.sweets=res;
  
      })
  }
    //this function is taken from the cart service 
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }
    
  }






