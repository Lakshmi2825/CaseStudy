/*import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from './Cart.model';
//import { Cart } from './cart';

@Injectable({
  providedIn: 'root'
})
export class CartItemService {
  

  constructor(private http: HttpClient) { }
  cartUrl='https://localhost:44333/api/AddToCarts';
  getAll():Observable<any>
  {
    return this.http.get<any>(`${this.cartUrl}`);
  }
  headers={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }
  addToCart(cart: Cart):Observable<any>{
    const body=JSON.stringify(cart);
    console.log(body)
    return this.http.post(this.cartUrl,body,this.headers)
  }
  Delete(Id:any):Observable<any>{
    return this.http.delete(this.cartUrl+"/"+Id,this.headers)
  }
}
*/