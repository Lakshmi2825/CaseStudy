import { HttpClient } from '@angular/common/http';
import { mergeAnalyzedFiles } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../api.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public mycartItemList : any=[]
  public meals = new BehaviorSubject<any>([]);
  public sweets = new BehaviorSubject<any>([]);
  public search = new BehaviorSubject<string>("");
  price: any;

  constructor(private ser:ApiService,private httpclient:HttpClient) { 
    

  }
  //apiUrl3='https://localhost:44333/api/AddToCarts';

  getProducts(){
    return this.meals,this.sweets.asObservable();
    //return this.http.get(`${this.apiUrl3}`);
  }
  setProduct(product : any){
    this.mycartItemList.push(...product);
    this.meals,this.sweets.next(product);
  } 
  addtoCart(product: any) {
    var count = 0;
    if(product!=null){

      let cartdata={

        id:product.id,

        Srno:product.id,

        ProductName:product.name,

        ProductImage:product.picture,

        Price:product.price,

        Quantity:product.quantity,

        Description:product.description,

        Total:product.total

      }

      this.httpclient.post("https://localhost:44333/api/AddToCarts",cartdata).subscribe(res=>console.log(res));

    }
    
    
      this.mycartItemList.map((m: any, index: any) => {
        if (product.id === m.id) {
          m.quantity=parseInt(m.quantity) +1; 
          m.total = parseInt(m.quantity) * parseFloat(m.price);
          count = 1;
        }        
      })
      if (count == 0) {
        this.mycartItemList.push(product);
        this.meals,this.sweets.next(this.mycartItemList);
        this.getTotalPrice();
      }
  }
  
 getTotalPrice():number{ 

  let grandTotal=0;
  
this.mycartItemList.forEach((m:any)=>{
grandTotal += parseFloat(m.total)
});
return grandTotal;

}
removeCartItem(product: any) {
  var result = confirm(`Are sure you want to delete the product ${product.name}`);
  if (result) {
  this.mycartItemList.map((m: any, index: any) => {
    if (product.id === m.id && product.quantity && parseInt(product.quantity) > 0) {
      m.quantity = parseInt(m.quantity) - 1;
      m.total = parseInt(m.quantity) * parseFloat(m.price);
      if (parseInt(m.quantity) == 0) {
        this.mycartItemList.splice(index, 1)
      }
    }
    else {
      if (product.id === m.id) {
        this.mycartItemList.splice(index, 1)
      }
    }
  })
  this.meals,this.sweets.next(this.mycartItemList);
}
}
  removeAllCart(){
    this.mycartItemList=[]
    this.meals,this.sweets.next(this.mycartItemList);

  }
 
}
