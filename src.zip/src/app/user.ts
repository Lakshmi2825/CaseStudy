export class User
{
    FullName : any;
    Email: any;
    MobileNumber: any;
    Password: any

}