import { Component, OnInit } from '@angular/core';

//import { CartItemService } from '../cart-item.service';
import { Cart } from '../Cart.model';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-mycart',
  templateUrl: './mycart.component.html',
  styleUrls: ['./mycart.component.css']
})
export class MycartComponent implements OnInit {
  public products:any=[];
  public grandTotal : number=0;
  cartitems:Cart[]=[];
  
  constructor(private cartService:CartService) { }

  ngOnInit(): void {
    this.cartService.getProducts()
    .subscribe(res=>{
      this.products=res;
      this.grandTotal=this.cartService.getTotalPrice();
    })
    //this.getAllCartitems();
    
  }
  /*getAllCartitems(){
    this.cartitemService.getAll().subscribe((res)=>{
      console.log("Checking getAllCartitems() method response======>",res);
      this.cartitems=res;
      this.grandTotal();

    })
  }
  DeleteItem(cartitem:any){
    console.log(cartitem.id);
    this.cartitemService.Delete(cartitem.id).subscribe((data)=>{
      console.log("Delete");
      this.getAllCartitems();
    })
  }
  finalTotal :Number=0;
  grandTotal(){
    for(var i =0;i<this.cartitems.length;i++){
      this.finalTotal=this.finalTotal+this.cartitems[i].total;
    }

  }*/

  removeItem(prod:any){
    this.cartService.removeCartItem(prod);
  }
  emptycart(){
    this.cartService.removeAllCart();
  }

}
