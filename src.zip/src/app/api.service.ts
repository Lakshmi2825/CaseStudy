import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  public mycartItemList : any=[]
  public meals = new BehaviorSubject<any>([]);
  public sweets = new BehaviorSubject<any>([]);
  


  constructor(private http:HttpClient) { }

  apiUrl='https://localhost:44333/api/Mealspacks';
  apiUrl1='https://localhost:44333/api/Sweets';
  apiUrl2='https://localhost:44333/api/Savories';
  //apiUrl3='https://localhost:44333/api/AddToCarts';
  

  

  getAllMealspackData():Observable<any>

  {

    return this.http.get(`${this.apiUrl}`);

  }
  getAllSweetsData():Observable<any>

  {

    return this.http.get(`${this.apiUrl1}`);

  }
  getAllSavoriesData():Observable<any>

  {

    return this.http.get(`${this.apiUrl2}`);

  }
  /*getProducts(){
    return this.meals,this.sweets.asObservable();
    //return this.http.get(`${this.apiUrl3}`);
  }
  addtoCart(product: any) {
    var count = 0;
      this.mycartItemList.map((m: any, index: any) => {
        if (product.id === m.id) {
          m.quantity=parseInt(m.quantity) +1; 
          m.total = parseInt(m.quantity) * parseFloat(m.price);
          count = 1;
        }        
      })
      if (count == 0) {
        this.mycartItemList.push(product);
        this.meals,this.sweets.next(this.mycartItemList);
        this.getTotalPrice();

      }
      return this.http.get(`${this.apiUrl3}`);

  }*/
  

  
}
