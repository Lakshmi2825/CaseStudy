import { Component, OnInit } from '@angular/core';

import {FormGroup,FormBuilder} from '@angular/forms';

import { HttpClient } from '@angular/common/http';

import{Router} from'@angular/router';



@Component({

selector: 'app-register',

templateUrl: './register.component.html',

styleUrls: ['./register.component.css']

})

export class RegisterComponent implements OnInit {

public RegisterForm !: FormGroup;

constructor(private formBuilder:FormBuilder,private http:HttpClient,private router:Router) { }



ngOnInit(): void {

this.RegisterForm=this.formBuilder.group({

fullname:[''],

email:[''],

mobileno:[''],

password:['']

})

}

signUp(){

this.http.post<any>("http://localhost:3000/signupUsers",this.RegisterForm.value).subscribe(res=>{

alert("Signup Successfull");

this.RegisterForm.reset();

this.router.navigate(['login']);

},err=>{

alert("Something went wrong");

})

}



}