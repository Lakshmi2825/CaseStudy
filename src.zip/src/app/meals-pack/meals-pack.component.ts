import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
//import { CartItemService } from '../cart-item.service';
import { Cart } from '../Cart.model';

import { CartService } from '../service/cart.service';
@Component({
  selector: 'app-meals-pack',
  templateUrl: './meals-pack.component.html',
  styleUrls: ['./meals-pack.component.css']
})
export class MealsPackComponent implements OnInit {
  meals : any =[];
  

  constructor(private cartService:CartService,private ser:ApiService) { 
   
  }

  ngOnInit(): void {
    this.ser.getAllMealspackData().subscribe((res:any)=>{

      this.meals=res;

    })
    
  }
  /*addToCart(price :number,Name:string,description:any,quantity:any,picture:string) {
  //Object.assign(prod,{quantity:1,total:prod.price});
  //this.cartService.addtoCart(prod);
  const total=price * quantity;
  const cartitem=new Cart (price,Name,description,quantity,total,picture);
  console.log("Checking MealspackComponent.addToCart() for cartitem " +cartitem);
  this.cartItemservice.addToCart(cartitem).subscribe((data)=>{
    console.log("addtocart===>",data);
  })

  }*/
  addtocart(prod:any){
    Object.assign(prod,{quantity:1,total:prod.price})
  this.cartService.addtoCart(prod);
}
  
  
}
