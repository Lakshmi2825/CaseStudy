
export class MealsModule {
  
  public picture :string;


  constructor(picture: string){
    this.picture=picture+".jpg";
  }
 }
 
