import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { User } from './user';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  apiUrl='https://localhost:44333/api/Registers';
  
  selectedUser:User ={
    FullName :'',
    Email:'',
    MobileNumber:'',
    Password:''

  }

  constructor(private http:HttpClient) { }
  postUser(user: User){
    return this.http.post(`${this.apiUrl}`,user)
  }
}
