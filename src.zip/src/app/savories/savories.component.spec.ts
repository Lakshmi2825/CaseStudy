import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavoriesComponent } from './savories.component';

describe('SavoriesComponent', () => {
  let component: SavoriesComponent;
  let fixture: ComponentFixture<SavoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SavoriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SavoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
