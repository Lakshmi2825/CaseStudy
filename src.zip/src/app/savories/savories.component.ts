import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { CartService } from '../service/cart.service';
@Component({
  selector: 'app-savories',
  templateUrl: './savories.component.html',
  styleUrls: ['./savories.component.css']
})
export class SavoriesComponent implements OnInit {
  saviors : any =[];

  constructor(private cartService:CartService,private ser:ApiService) {
    
   }
    ngOnInit(): void {
      this.ser.getAllSavoriesData().subscribe((res:any)=>{

        this.saviors=res;
  
      })
      
    }
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }
    
  }
