const express = require('express')
var mysql = require('mysql')
const app = express()
const port = 7766

app.use(express.urlencoded({extended:false}))
app.use(express.json())

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'M8$tek12',
    database: 'food-plaza',
    port:3306
  })
  
  connection.connect()
  app.get('/list', (req, res) => {
      var qry_select="SELECT * FROM `food-plaza`.products"
    connection.query(qry_select, function (err, rows, fields) {
        if (err) throw err
        res.send(rows)
      
        console.log(rows.length+"projects fetched from the db")
      })
    })
  
 /*var projectData=[
   {"_id":"1","index":"0","price":"150","picture":"Andhra.jpg","name":"Andhra Meals","Description":"Andhra Meals(150g)"},
   {"_id":"2","index":"1","price":"180","picture":"Chinees.jpg","name":"Chinees Meals","Description":"Chinees Meals(250g)"}
 ]
 app.get('/list', (req, res) => {
   console.log(projectData.length+"projects fetched")
   res.send(projectData)
 })
  */

app.get('/', (req, res) => {
  res.send('Welcome to food-plaza!')
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})